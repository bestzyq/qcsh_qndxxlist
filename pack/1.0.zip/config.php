<?php
$dbHost = '';
$dbName = '';
$dbUsername = '';
$dbPassword = '';
$conn = new PDO("mysql:host=$dbHost;dbname=$dbName;charset=utf8", $dbUsername, $dbPassword);
?>
